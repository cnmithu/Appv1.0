# Appv1.0
###### Global Gaming – Application Challenge v1.0

I have used PHP codeignitor framework(MVC) as well as for design i used Bootstarp. For movie data source, i have used dummy json data with name db.json which is stored over project root directory. I planned to used json dummy data because thing kind of serarch and filtering i am used to do with Database and API. It was challenging as well as interesting for me to do paginition on JSON Array. I did filter and search manually even though I could have used jquery datatable to get filter and search automatically.